﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 电灯信号图
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;//创建画板




            Pen pen1 = new Pen(Color.Black, 5);//创建画笔

            Point[] points00 =
            {
                new Point (5,5),
                new Point (5,795),
                new Point (1000,795),
                new Point (1000,5),
                new Point (5,5)
            };//多个点组成一条线
            g.DrawLines(pen1, points00);
            g.DrawLine(pen1, 5, 565, 1000, 565);//画直线
            g.DrawLine(pen1, 100, 410, 100, 450);//画直线




            Pen pen = new Pen(Color.Black, 2);//创建画笔

            g.DrawRectangle(pen, 300, 350, 300, 50);//画矩形
            g.DrawLine(pen, 450, 350, 450, 400);//画直线
            g.DrawString("DX", new Font("宋体", 28), new SolidBrush(Color.Black), new PointF(350, 360));//写文字
            g.DrawString("XJZ220", new Font("宋体", 28), new SolidBrush(Color.Black), new PointF(50, 50));//写文字
            g.DrawString("XJF220", new Font("宋体", 28), new SolidBrush(Color.Black), new PointF(820, 50));//写文字
            g.DrawString("DLQ1", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(15, 150));//写文字
            g.DrawString("0.5A", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(110, 150));//写文字
            g.DrawString("DLQ2", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(800, 150));//写文字
            g.DrawString("0.5A", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(910, 150));//写文字
            g.DrawString("DJ", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(130, 250));//写文字
            g.DrawString("XJ", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(30, 400));//写文字
            g.DrawString("05-2", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(110, 510));//写文字
            g.DrawString("05-1", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(465, 510));//写文字
            g.DrawString("05-3", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(900, 510));//写文字
            g.DrawString("F-A", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(110, 535));//写文字
            g.DrawString("F-B", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(465, 535));//写文字
            g.DrawString("F-BAH", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(900, 535));//写文字
            g.DrawString("1", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(110, 570));//写文字
            g.DrawString("2", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(465, 570));//写文字
            g.DrawString("3", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(900, 570));//写文字
            g.DrawString("A", new Font("宋体", 28), new SolidBrush(Color.Black), new PointF(190, 760));//写文字
            g.DrawString("B", new Font("宋体", 28), new SolidBrush(Color.Black), new PointF(550, 760));//写文字
            g.DrawString("1", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(105, 115));//写文字
            g.DrawString("2", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(105, 180));//写文字
            g.DrawString("1", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(895, 115));//写文字
            g.DrawString("2", new Font("宋体", 20), new SolidBrush(Color.Black), new PointF(895, 200));//写文字
            g.DrawString("6", new Font("宋体", 28), new SolidBrush(Color.Black), new PointF(105, 380));//写文字

            g.DrawEllipse(pen, 98, 540, 4, 4);//画圆
            g.DrawLine(pen, 104, 534, 96, 544);//画直线
            g.DrawEllipse(pen, 98, 555, 4, 4);//画圆
            g.DrawLine(pen, 104, 549, 96, 559);//画直线
            g.DrawEllipse(pen, 98, 570, 4, 4);//画圆
            g.DrawLine(pen, 104, 564, 96, 574);//画直线

            g.DrawEllipse(pen, 448, 540, 4, 4);//画圆 
            g.DrawLine(pen, 454, 534, 444, 544);//画直线
            g.DrawEllipse(pen, 448, 555, 4, 4);//画圆 
            g.DrawLine(pen, 454, 549, 444, 559);//画直线
            g.DrawEllipse(pen, 448, 570, 4, 4);//画圆
            g.DrawLine(pen, 454, 564, 444, 574);//画直线

            g.DrawEllipse(pen, 898, 540, 4, 4);//画圆
            g.DrawLine(pen, 904, 534, 896, 544);//画直线
            g.DrawEllipse(pen, 898, 555, 4, 4);//画圆
            g.DrawLine(pen, 904, 549, 896, 559);//画直线
            g.DrawEllipse(pen, 898, 570, 4, 4);//画圆
            g.DrawLine(pen, 904, 564, 896, 576);//画直线

            g.DrawBezier(pen, 515, 750, 525, 730, 535, 770, 545, 750);//画波浪线
            g.DrawBezier(pen, 165, 750, 175, 730, 185, 770, 195, 750);//画波浪线
            g.DrawBezier(pen, 415, 210, 425, 190, 435, 230, 445, 210);//画波浪线
            g.DrawBezier(pen, 415, 250, 425, 230, 435, 270, 445, 250);//画波浪线
            g.DrawBezier(pen, 435, 625, 445, 605, 455, 645, 465, 625);//画波浪线
            g.DrawBezier(pen, 475, 625, 485, 605, 495, 645, 505, 625);//画波浪线
            g.DrawBezier(pen,  85, 625,  95, 605, 105, 645, 115, 625);//画波浪线
            g.DrawBezier(pen, 125, 625, 135, 605, 145, 645, 155, 625);//画波浪线



            Point[] points =
            {
                new Point (95,95),
                new Point (100,100),
                new Point (100,210),
                new Point (400,210)
            };//多个点组成一条线
            g.DrawLines(pen, points);
            g.DrawEllipse(pen, 400, 185, 50, 50);//画圆
            g.DrawEllipse(pen, 400, 220, 50, 50);//画圆
            Point[] points6 =
            {
                new Point (100,650),
                new Point (100,700),
                new Point (900,700),
                new Point (900,245),
                new Point (450,245)
            };//多个点组成一条线
            g.DrawLines(pen, points6);

            g.DrawLine(pen, 105, 95, 100, 100);//画直线
            g.DrawRectangle(pen, 90, 150, 20, 50);//画矩形
            Point[] points7 =
          {
                new Point (400,245),
                new Point (100,245),
                new Point (100,400)
            };//多个点组成一条线
            g.DrawLines(pen, points7);
            g.DrawEllipse(pen, 75, 250, 50, 50);//画圆
            g.DrawLine(pen, 85, 290, 115, 290);//画直线
            Point[] points5 =
           {
                new Point (100,290),
                new Point (85,260),
                new Point (115,260),
                new Point (100,290)
            };//多个点组成一条线
            g.DrawLines(pen, points5);

          
            g.DrawEllipse(pen, 95, 400, 10, 10);//画圆
            g.DrawEllipse(pen, 115, 425, 10, 10);//画圆
            g.DrawEllipse(pen, 95, 450, 10, 10);//画圆
            g.DrawLine(pen, 105, 405, 115, 430);//画直线

            g.DrawLine(pen, 100, 460, 100, 600);//画直线
            g.DrawEllipse(pen, 75, 600, 50, 50);//画圆
            g.DrawEllipse(pen, 110, 600, 50, 50);//画圆
            Point[] points0 =
              {
                new Point (135,600),
                new Point (135,580),
                new Point (235,580),
                new Point (235,750),
                new Point (210,750)
            };//多个点组成一条线
            g.DrawLines(pen, points0);
            g.DrawEllipse(pen, 160, 725, 50, 50);//画圆
            Point[] pointso =
            {
                new Point(160, 750),
                new Point(135, 750),
                new Point(135, 650)
            };//多个点组成一条线
            g.DrawLines(pen, pointso);

            Point[] points1 =
              {
                new Point (125,430),
                new Point (450,430),
                new Point (450,600)
            };//多个点组成一条线
            g.DrawLines(pen, points1);
            g.DrawEllipse(pen, 425, 600, 50, 50);//画圆
            g.DrawEllipse(pen, 460, 600, 50, 50);//画圆
            g.DrawLine(pen, 450, 650, 450, 700);//画直线
            Point[] points2 =
              {
                new Point (485,600),
                new Point (485,580),
                new Point (585,580),
                new Point (585,750),
                new Point (560,750)
            };//多个点组成一条线
            g.DrawLines(pen, points2);
            g.DrawEllipse(pen, 510, 725, 50, 50);//画圆
            Point[] points3 =
            {
                new Point(510, 750),
                new Point(485, 750),
                new Point(485, 650)
            };//多个点组成一条线
            g.DrawLines(pen, points3);

            pen.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 5);//直线尾部加箭头
            Point[] points4 =
           {
                new Point (450,210),
                new Point (900,210),
                new Point (900,100),
            };//多个点组成一条线
            g.DrawLines(pen, points4);
            g.DrawRectangle(pen, 890, 150, 20, 50);//画矩形

            g.DrawLine(pen, 70, 290, 70, 260);//画直线
            g.DrawLine(pen, 80, 420, 80, 450);//画直线
        }
    }
}
