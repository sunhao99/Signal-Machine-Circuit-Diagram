﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//连接数据库必须要添加的

namespace MyForm01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mydraw(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);//创建画笔,黑色，宽度为2的画笔
            Pen pen_bold = new Pen(Color.Black, 4);
            Pen pen_bold3 = new Pen(Color.Black, 3);
            Pen pen_dash = new Pen(Color.Black, 2);
            Pen pen_arr = new Pen(Color.Black, 2);
            Pen pen_arr_bold = new Pen(Color.Black, 2);
            pen_arr_bold.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 5);
            pen_arr_bold.DashPattern = new float[] { 4.0F, 2.0F, 4.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 5);
            pen_dash.DashPattern = new float[] { 4.0F, 2.0F, 4.0F };


            string ConStr = "server=(local);user id=sa;pwd=1234;database=DC";//输入自己的SQL数据库密码及数据库名称           
            string Sql = "select * from dbo.line";//myuser换成自己的数据表名称
            SqlConnection con = new SqlConnection(ConStr);
            SqlDataAdapter ada = new SqlDataAdapter(Sql, con);
            DataTable dt = new DataTable();
            ada.Fill(dt);

            int num = dt.Rows.Count;//行数
            int a = int.Parse(dt.Rows[0][2].ToString());
            int b = int.Parse(dt.Rows[0][3].ToString());
            int c = int.Parse(dt.Rows[0][4].ToString());
            int d = int.Parse(dt.Rows[0][5].ToString());

            pen.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 5);
            pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;//虚线
            g.DrawLine(pen, 100, 100, 800, 100);//画直线
            g.DrawLine(pen, a, b, c, d);//画直线

            Point[] points =
            {
                new Point(100,50),
                new Point(100,100),
                new Point(150,50),
                new Point(200,200)
            };
            g.DrawLines(pen, points);

            //g.DrawRectangle(pen, 200, 200, 200, 200);//画矩形

            //Rectangle rect = new Rectangle(10, 10, 50, 50);           
            //SolidBrush b1 = new SolidBrush(Color.Black);//定义单色画刷          
            //g.FillRectangle(b1, rect);//填充这个矩形
            g.FillRectangle(new SolidBrush(Color.Black), new Rectangle(10, 10, 50, 50));

            g.DrawEllipse(pen, 200, 200, 200, 200); //画椭圆

            g.DrawString("点灯单元", new Font("宋体", 28), new SolidBrush(Color.Blue), new PointF(160, 160));//绘制文字

        }
    }
}
