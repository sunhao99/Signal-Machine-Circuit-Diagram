﻿using System;
using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Windows.Forms.VisualStyles;
using System.Windows.Forms;

namespace 进站信号机电灯电路图
{
    public partial class Form1 : Form
    {
        #region 初始化
        public Form1()
        {
            InitializeComponent();
        }
        #endregion
        #region 主函数
        protected void LayBrush01(object sender, PaintEventArgs e)
        { 
 
            #region 画板+画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen_bold = new Pen(Color.Black, 3);
            Pen pen_lay = new Pen(Color.Black, 4);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 4.0F, 2.0F, 4.0F };
            Pen pen = new Pen(Color.Black, 2);//创建画笔
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 4.0F, 2.0F, 4.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(4, 7);
            MyLibray JiDian = new MyLibray();
            Sig sig = new Sig();
            #endregion
            #region 信号机
            g.DrawLine(pen, 120, 37, 360, 37);
            g.DrawLine(pen_dash, 170, 20, 170, 50);
            g.DrawLine(pen_dash, 255, 20, 255, 50);//虚线
            g.DrawLine(pen, 170, 25, 170 + 7, 25);
            g.DrawEllipse(pen, 177, 25 - 6, 12, 12);//yellow
            g.FillEllipse(new SolidBrush(Color.Yellow), 177, 25 - 6, 12, 12);
            g.DrawEllipse(pen, 177 + 12, 25 - 6, 12, 12);//Green
            g.FillEllipse(new SolidBrush(Color.Green), 177 + 12, 25 - 6, 12, 12);
            g.DrawLine(pen, 255, 25, 255 + 7, 25);
            g.DrawEllipse(pen, 262, 19, 12, 12);
            g.DrawLine(pen, 262 + 12, 25, 262 + 20, 25);
            g.DrawEllipse(pen, 282, 19, 12, 12);
            g.FillEllipse(new SolidBrush(Color.Yellow), 282, 19, 12, 12);
            g.DrawEllipse(pen, 282 + 12, 19, 12, 12);
            g.FillEllipse(new SolidBrush(Color.Red), 282 + 12, 19, 12, 12);
            g.DrawEllipse(pen, 282 + 24, 19, 12, 12);
            g.FillEllipse(new SolidBrush(Color.Green), 282 + 24, 19, 12, 12);
            g.DrawEllipse(pen, 282 + 36, 19, 12, 12);
            g.FillEllipse(new SolidBrush(Color.Yellow), 282 + 36, 19, 12, 12);
            #endregion
            #region 外框线
            //画实线 
            g.DrawRectangle(pen_lay, 5, 5, 1090, 770);//外边框
            g.DrawRectangle(pen_bold, 5, 55, 570, 720); //内边框1
            g.DrawRectangle(pen_bold, 575, 55, 160, 190);//内边框2  BXG 52-4
            g.DrawLine(pen_bold, 5, 546, 575, 546);//线框
            g.DrawString("进站信号机电灯电路图", new Font("隶书", 12), new SolidBrush(Color.Black), new PointF(900, 750));//进站信号机电灯电路图
            //画虚线  230,274
            g.DrawLine(pen_dash, 5, 55 + 274, 5 + 230, 55 + 274);//LXZ_DASH
            g.DrawLine(pen_dash, 5 + 230, 55, 5 + 230, 55 + 274);//LXZ_DASH
            g.DrawRectangle(pen_dash, 415, 55, 120, 277);//LXZ_DASH
            #endregion
            #region 矩形框
            //画框LXZ，长45，宽25
            g.DrawRectangle(pen_bold, 110, 55 + 45, 45, 25);
            g.DrawRectangle(pen_bold, 110 + 45, 55 + 45, 45, 25);
            g.DrawString("LXZ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(110 + 12, 100 + 6));//LXZ  ,12,6
            //画框YX
            g.DrawRectangle(pen_bold, 318, 55 + 45, 45, 25);
            g.DrawRectangle(pen_bold, 318 + 45, 55 + 45, 45, 25);
            g.DrawString("YX", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(318 + 12, 100 + 6));//YX  ,12,6
            //画框LXZ2
            g.DrawRectangle(pen_bold, 445, 55, 45, 25);
            g.DrawRectangle(pen_bold, 445 + 45, 55, 45, 25);
            g.DrawString("LXZ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(445 + 12, 55 + 6));//LXZ  ,12,6
            //画框BXG 52-4
            g.DrawRectangle(pen_bold, 575 + 34, 55, 45, 25);
            g.DrawRectangle(pen_bold, 575 + 34 + 45, 55, 45, 25);
            g.DrawString("BXG", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(575 + 34 + 12, 55 + 6));//BXG  ,12,6
            g.DrawString("52-4", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(575 + 34 + 45 + 12, 55 + 6));//52-4  ,12,6
            #endregion
            #region XJZ220
            Point[] XJZ220_1 =
            {
                new Point(30,89),
                new Point(30+5,89+5),
                new Point(30+10,89)
            };
            g.DrawLines(pen, XJZ220_1);
            g.DrawString("XJZ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(30 - 8, 89 - 15));//XJZ [-8,-15]
            g.DrawString("220", new Font("微软雅黑", 6), new SolidBrush(Color.Black), new PointF(30 + 10, 89 - 10));//220 [+10,-10]
            Point[] XJZ220_2 =
            {
                new Point(290,89),
                new Point(290+5,89+5),
                new Point(290+10,89)
            };
            g.DrawLines(pen, XJZ220_2);
            g.DrawString("XJZ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(290 - 8, 89 - 15));//XJZ [-8,-15]
            g.DrawString("220", new Font("微软雅黑", 6), new SolidBrush(Color.Black), new PointF(290 + 10, 89 - 10));//220 [+10,-10]
            Point[] XJZ220_3 =
            {
                new Point(590,89),
                new Point(590+5,89+5),
                new Point(590+10,89)
            };
            g.DrawLines(pen, XJZ220_3);
            g.DrawString("XJZ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(590 - 8, 89 - 15));//XJZ [-8,-15]
            g.DrawString("220", new Font("微软雅黑", 6), new SolidBrush(Color.Black), new PointF(590 + 10, 89 - 10));//220 [+10,-10]
            #endregion
            #region XJF220
            g.DrawLine(pen_arr, 470, 100, 470, 100 - 6);
            g.DrawString("XJF", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(470 - 8, 96 - 15));//XJF [-8,-15]
            g.DrawString("220", new Font("微软雅黑", 6), new SolidBrush(Color.Black), new PointF(470 + 10, 96 - 10));//220 [+10,-10]
            g.DrawLine(pen_arr, 590 + 95, 100, 590 + 95, 100 - 6);
            g.DrawString("XJF", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(590 + 95 - 8, 96 - 15));//XJF [-8,-15]
            g.DrawString("220", new Font("微软雅黑", 6), new SolidBrush(Color.Black), new PointF(590 + 95 + 10, 96 - 10));//220 [+10,-10]
            #endregion
            #region DLQ1-BXG1-DLQ2-DLQ3-BXG2
            g.DrawLine(pen, 35, 94, 35, 140 + 12 + 12);//DLQ1
            g.DrawRectangle(pen, 35 - 3, 140, 6, 12);//小矩形DLQ1长宽：12:6
            g.DrawString("DLQ1", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(35 + 6, 140));//DLQ1
            g.DrawLine(pen, 35, 164, 100, 164);
            g.DrawEllipse(pen, 100, 164 - 5, 10, 10);//⚪：BXG1
            g.DrawEllipse(pen, 100, 164 + 6 - 5, 10, 10);//⚪1：BXG1
            g.DrawString("BXG1", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(100 - 5, 164 - 5 - 13));//BXG1
            g.DrawLine(pen, 100 + 10, 164, 470, 164);//2-I2-I1-2
            g.DrawLine(pen, 470, 164, 470, 100);//XJF220↑
            g.DrawRectangle(pen, 470 - 3, 140, 6, 12);//DLQ2
            g.DrawString("DLQ2", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(470 - 3 - 40, 140));//DLQ2
            g.DrawLine(pen, 470, 164, 470, 164 + 5);
            g.DrawLine(pen, 470, 164 + 5, 380, 164 + 5);//BXG2
            g.DrawEllipse(pen, 370, 164, 10, 10);//⚪：BXG2
            g.DrawEllipse(pen, 370, 164 + 6, 10, 10);
            g.DrawString("BXG2", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(370 - 5, 150));//BXG2
            g.DrawLine(pen, 370, 169, 295, 169);
            g.DrawLine(pen, 295, 169, 295, 94);//DLQ2↑
            g.DrawRectangle(pen, 295 - 3, 140, 6, 12);
            g.DrawString("DLQ3", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(295 + 3, 140));//DLQ3
            g.DrawLine(pen, 470, 175, 470, 180);//470,175
            g.DrawLine(pen, 470, 175, 380, 175);//380,175
            g.DrawLine(pen, 370, 175, 295, 175);//2DJ01
            #endregion
            #region 预告信号机
            g.DrawLine(pen, 735, 190, 735 + 70 + 90, 190);//U-L
            g.DrawLine(pen, 805, 190, 805, 183);
            g.DrawLine(pen, 805, 183 - 16, 805, 183 - 16 - 27);//U-2
            JiDian.XuHao(805 - 8, 140 - 8, "2", e);
            g.DrawLine(pen, 895, 190, 895, 183);
            g.DrawLine(pen, 895, 167, 895, 140);//L-2
            JiDian.XuHao(895 - 8, 140 - 8, "1", e);
            sig.PaintAll2(805, 167, "U", e);
            sig.PaintAll(895, 167, "L", e);
            g.DrawRectangle(pen, 805 - 13, 190 + 11, 190, 120);
            g.DrawString("YXD   预告信号机", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(805, 325));//YXD  预告信号机
            #endregion
            #region BXG-DLQ4-DLQ5
            g.DrawEllipse(pen, 645, 184 - 5, 10, 10);//⚪：BXG
            g.DrawEllipse(pen, 645, 184 + 6 - 5, 10, 10);//⚪1：BXG
            g.DrawString("BXG", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(645 - 5, 184 - 5 - 13));//BXG
            g.DrawLine(pen, 645, 190, 595, 190);//F601-3
            g.DrawString("F601-3", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(645 + 20, 190 + 3));
            g.DrawLine(pen, 645 + 10, 190, 800, 190);
            g.DrawLine(pen, 645, 184, 595, 184);
            g.DrawLine(pen, 595, 184, 595, 94);
            g.DrawRectangle(pen, 595 - 3, 184 - 20 - 12, 6, 12);
            g.DrawString("DLQ4", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(595 + 5, 152 - 30));
            g.DrawLine(pen, 645 + 10, 184, 685, 184);
            g.DrawLine(pen, 685, 184, 685, 94);
            JiDian.Rec(685, 152, "DLQ5", e);
            #endregion
            #region DJ
            g.DrawLine(pen, 35, 170, 35, 205 + 26 + 11);
            g.DrawEllipse(pen, 35 - 13, 205, 26, 26);//大圆
            Point[] Angle3 =
            {
                new Point(35,205+7+8),
                new Point(35-5,205+7),
                new Point(35+5,205+7),
                new Point(35,205+7+8),
                new Point(35-5,205+15),
                new Point(35+5,205+15)
            };
            g.DrawLines(pen, Angle3);
            g.DrawLine(pen, 35 - 20, 210, 15, 230);
            g.DrawLine(pen_arr, 15, 216, 15, 210);
            g.DrawString("DJ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(35 + 15, 205 + 9));
            #endregion
            #region 2DJ
            g.DrawLine(pen, 295, 175, 295, 205 + 26 + 11);
            g.DrawEllipse(pen, 295 - 13, 205, 26, 26);//大圆
            Point[] Angle4 =
            {
                new Point(295,205+7+8),
                new Point(295-5,205+7),
                new Point(295+5,205+7),
                new Point(295,205+7+8),
                new Point(295-5,205+15),
                new Point(295+5,205+15)
            };
            g.DrawLines(pen, Angle4);
            g.DrawLine(pen, 295 - 20, 210, 295 - 20, 230);
            g.DrawLine(pen_arr, 275, 224, 275, 230);
            g.DrawString("2DJ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(295 + 15, 205 + 9));
            #endregion
            #region  接点调用函数
            JiDian.PaintXia(35, 242, "LXJ", e);
            g.DrawLine(pen, 35, 242 + 20, 35, 310);
            JiDian.Cir(35, 310, "05-8", e);
            g.DrawLine(pen, 35, 314, 35, 345);
            JiDian.Cir(35, 345, "04-9", e);
            g.DrawLine(pen, 35, 345, 35, 360);
            JiDian.PaintShang(35, 360, "ZXJ", e);
            g.DrawLine(pen, 35, 380, 35, 410);
            JiDian.PaintXia(35, 410, "2DJ", e);
            g.DrawLine(pen, 35, 430, 35, 450);
            JiDian.Cir(35, 450, "02-14", e);
            g.DrawLine(pen, 35, 450, 35, 470);
            JiDian.PaintXiaYou(35, 470, "LUXJ", e);
            g.DrawLine(pen, 35, 490, 35, 490 + 13);
            JiDian.Cir(35, 503, "05-11", e);
            g.DrawLine(pen, 35, 507, 35, 524);
            JiDian.Cir(35, 524, "F-IU", e);
            g.DrawLine(pen, 35, 528, 35, 546 + 15 + 4 + 27);
            JiDian.Cir(35, 561, "1", e);

            //LXJ  05-12
            g.DrawLine(pen, 35 + 12, 242 + 12, 35 + 12 + 166, 242 + 12);
            g.DrawLine(pen, 213, 254, 213, 254 + 36 + 20);
            JiDian.Cir(213, 290 + 20, "05-12", e);
            g.DrawLine(pen, 213, 310 + 4, 213, 592);
            JiDian.Cir(213, 524, "F-H", e);
            JiDian.Cir(213, 561, "3", e);
            //ZXJ  02-15
            g.DrawLine(pen, 35 + 12, 360 + 12, 35 + 12 + 78, 360 + 12);//12,12
            g.DrawLine(pen, 125, 372, 125, 372 + 27 + 41);
            #region 2DJ
            g.DrawLine(pen, 35 + 12, 470 + 12, 35 + 12 + 20, 470 + 12);
            g.DrawEllipse(pen, 67, 480, 4, 4);
            g.DrawEllipse(pen, 67 + 15, 480, 4, 4);
            g.DrawEllipse(pen, 67 + 11, 480 + 8, 4, 4);
            g.DrawLine(pen_dash, 67 + 4, 482, 82, 482);
            g.DrawLine(pen, 70, 483, 78, 488);
            g.DrawLine(pen, 85, 488, 85, 510);
            g.DrawLine(pen_arr, 85, 504, 85, 510);
            g.DrawString("2DJ", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(67, 465));//2DJ
            #endregion
            g.DrawLine(pen, 82 + 4, 482, 125, 482);
            JiDian.Cir(125, 399, "02-15", e);
            JiDian.PaintXiaZuo(125, 440, "TXJ", e);
            g.DrawLine(pen, 35, 450, 115, 450);
            g.DrawLine(pen, 125, 372 + 20, 125, 592);
            JiDian.Cir(125, 503, "05-10", e);
            JiDian.Cir(125, 524, "F-L", e);
            JiDian.Cir(125, 561, "2", e);
            //BXG1 II2-II3
            g.DrawLine(pen, 35, 170, 100, 170);
            g.DrawLine(pen, 110, 170, 110 + 30, 170);
            g.DrawLine(pen, 140, 170, 140, 170 + 20);
            g.DrawLine(pen, 140, 190, 595, 190);
            //2DJ-LXJF
            g.DrawLine(pen, 295, 205 + 26, 295, 205 + 26 + 16);
            JiDian.PaintXia(295, 247, "LXJF", e);
            g.DrawLine(pen, 295, 247 + 20, 295, 360);
            JiDian.PaintXia(295, 360, "ZXJ", e);
            g.DrawLine(pen, 295, 360 + 20, 295, 450);
            JiDian.Cir(295, 450, "06-7", e);
            g.DrawLine(pen, 295, 454, 295, 470);
            JiDian.PaintXiaYou(295, 470, "TXJ", e);
            g.DrawLine(pen, 295, 470 + 20, 295, 503);
            JiDian.Cir(295, 503, "05-9", e);
            g.DrawLine(pen, 295, 503 + 4, 295, 592);
            JiDian.Cir(295, 524, "F-2U", e);
            JiDian.Cir(295, 561, "4", e);
            //LXJF-YXJ
            g.DrawLine(pen, 295 + 12, 247 + 12, 295 + 78 + 12, 259);
            g.DrawLine(pen, 385, 259, 385, 470);
            JiDian.PaintXia(385, 470, "YXJ", e);
            g.DrawLine(pen, 385, 470 + 20, 385, 592);
            JiDian.Cir(385, 503, "05-8", e);
            JiDian.Cir(385, 524, "F-YB", e);
            JiDian.Cir(385, 561, "5", e);
            //ZXJ-LUXJ
            g.DrawLine(pen, 295 + 12, 360 + 12, 307 + 25, 372);
            g.DrawLine(pen, 332, 372, 332, 372 + 23);
            JiDian.PaintXiaZuo2(332, 395, "LUXJ", e);
            g.DrawLine(pen, 332, 395 + 20, 332, 445);
            g.DrawLine(pen, 295, 445, 332, 445);
            //JXJ
            g.DrawLine(pen, 470, 175, 470, 247);
            JiDian.PaintXia(470, 247, "LXJ", e);//LXJ
            g.DrawLine(pen, 470, 247 + 20, 470, 620);//LXJ-05-7
            JiDian.Cir(470, 310, "05-7", e);//05-7
            g.DrawLine(pen, 470 + 12, 247 + 12, 470 + 12 + 18, 247 + 12);
            g.DrawLine(pen, 500, 259, 500, 628);
            JiDian.Cir(470 + 12 + 18, 310, "05-6", e);
            JiDian.Cir(470, 524, "F-\nLUH", e);
            JiDian.Cir(470, 561, "6", e);
            JiDian.Cir(500, 503, "05-6", e);
            JiDian.Cir(500, 524, "F-\nHH", e);
            JiDian.Cir(500, 561, "7", e);
            g.DrawLine(pen, 500, 390, 500 + 30, 390);
            g.DrawLine(pen, 530, 390, 530, 390 + 25);//YXJ-6
            g.DrawLine(pen, 530, 415 + 20, 530, 640);
            JiDian.PaintXia(530, 415, "YXJ", e);//YXJ
            JiDian.Cir(530, 503, "05-5", e);
            JiDian.Cir(530, 524, "F-\nYBH", e);
            JiDian.Cir(530, 561, "8", e);
            //圈1-2
            g.DrawLine(pen, 470, 561 + 22, 540, 561 + 22);//圈一
            //g.DrawEllipse(pen,540,583-6,12,12);
            //g.DrawString("1", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(540,577));
            JiDian.XuHao(540, 583, "1", e);
            g.DrawLine(pen, 500, 561 + 50, 540, 561 + 50);//圈二
            JiDian.XuHao(540, 611, "2", e);
            //g.DrawEllipse(pen,540,611-6,12,12);
            //g.DrawString("2", new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(540,604));//2
            g.DrawLine(pen, 35, 608, 35, 620);//F-IU,1
            g.DrawLine(pen, 35, 620, 470, 620);
            g.DrawLine(pen, 125, 608, 125, 620);//F-L,2
            g.DrawLine(pen, 295, 608, 295, 620);//F-2U,4
            g.DrawLine(pen, 213, 608, 213, 628);//F-H,3
            g.DrawLine(pen, 213, 628, 500, 628);
            g.DrawLine(pen, 385, 608, 385, 640);
            g.DrawLine(pen, 385, 640, 530, 640);//F-YB


            //  信号灯

            sig.PaintAll(35, 592, "1U", e);
            sig.PaintAll2(213, 592, "H", e);
            sig.PaintAll(125, 592, "L", e);
            sig.PaintAll(295, 592, "2U", e);
            sig.PaintAll(385, 592, "YB", e);
            #endregion

        }
        #endregion
        #region 红灯电灯电路图
        private void button1_Click(object sender, EventArgs e)
        {
            //红灯
            Graphics g = this.CreateGraphics();
            Pen penH = new Pen(Color.Red, 3);
            Point[] redPoints =
            {
                new Point(35, 90),
                //new Point(35,164),
                //new Point(100,164),
                //new Point(100,169),
                //new Point(35,169),
                new Point(35,242),
                new Point(35+8,242+11),
                new Point(43+170,253),
                new Point(213,628),
                new Point(500,628),
                new Point(500,259),
                new Point(500-18,259),
                new Point(470,247),
                new Point(470,98)
            };
            g.DrawLines(penH, redPoints);
            g.DrawRectangle(penH, 213 + 11, 592 - 12, 50, 142);
        }
        #endregion
        #region 黄灯电灯电路图
        private void button2_Click(object sender, EventArgs e)
        {
            //黄灯
            Graphics g = this.CreateGraphics();
            Pen penH = new Pen(Color.Yellow, 3);
            Point[] redPoints =
            {
                new Point(35, 90),
                new Point(35,360),
                new Point(35+12,360+12),
                new Point(125,372),
                new Point(125,372+27+41),
                new Point(118,450),
                new Point(35,450),
                new Point(35, 620),
                new Point(470, 620),
                new Point(470,98)
            };
            g.DrawLines(penH, redPoints);
            g.DrawRectangle(penH, 35 + 11, 592 - 12, 50, 142);
            
        }
        #endregion
        #region 绿灯点灯电路图
        private void button3_Click(object sender, EventArgs e)
        {
            //绿灯
            Graphics g = this.CreateGraphics();
            Pen penG = new Pen(Color.Green, 3);
            Point[] redPoints =
            {
                new Point(35, 90),
                new Point(35,360),
                new Point(35+12,360+12),
                new Point(125,372),
                new Point(125,620),
                new Point(470, 620),
                new Point(470,98)
            };
            g.DrawLines(penG, redPoints);
            g.DrawRectangle(penG, 125 + 11, 592 - 12, 50, 142);
        }
        #endregion
        #region 绿黄灯电灯电路图
        private void button4_Click(object sender, EventArgs e)
        {
            //绿黄灯
            //绿灯
            Graphics g = this.CreateGraphics();
            Pen penIiu = new Pen(Color.GreenYellow, 3);
            Point[] redPoints =
            {
                new Point(35, 90),
                new Point(35,360),
                new Point(35+12,360+12),
                new Point(125,372),
                new Point(125,620),
                new Point(470, 620),
                new Point(470,98)
            };
            g.DrawLines(penIiu, redPoints);
            g.DrawRectangle(penIiu, 125 + 11, 592 - 12, 50, 142);
            //II黄灯
            Point[] LiuPoints =
            {
                new Point(295,90),
                new Point(295,360),
                new Point(295+12,360+12),
                new Point(307+25,372),
                new Point(332,372),
                new Point(332,445),
                new Point(295,445),
                new Point(295,620),
                new Point(470,620),
                new Point(470,98)
            };
            g.DrawLines(penIiu,LiuPoints);
            g.DrawRectangle(penIiu,295+11,592-12,50,142);
        }
        #endregion
        #region 双黄灯电灯电路图
        private void button5_Click(object sender, EventArgs e)
        {
            //双黄灯
            //第一黄灯
            Graphics g = this.CreateGraphics();
            Pen penH = new Pen(Color.Gold, 3);
            Point[] redPoints =
            {
                new Point(35, 90),
                new Point(35,360),
                new Point(35+12,360+12),
                new Point(125,372),
                new Point(125,372+27+41),
                new Point(118,450),
                new Point(35,450),
                new Point(35, 620),
                new Point(470, 620),
                new Point(470,98)
            };
            g.DrawLines(penH, redPoints);
            g.DrawRectangle(penH, 35 + 11, 592 - 12, 50, 142);
            //第二黄灯
            Point[] LiuPoints =
            {
                new Point(295,90),
                new Point(295,360),
                new Point(295+12,360+12),
                new Point(307+25,372),
                new Point(332,372),
                new Point(332,445),
                new Point(295,445),
                new Point(295,620),
                new Point(470,620),
                new Point(470,98)
            };
            g.DrawLines(penH, LiuPoints);
            g.DrawRectangle(penH, 295 + 11, 592 - 12, 50, 142);
        }
        #endregion
        #region 红白灯电灯电路图
        private void button6_Click(object sender, EventArgs e)
        {
            //红白灯
            Graphics g = this.CreateGraphics();
            Pen penH = new Pen(Color.Red, 3);
            Point[] redPoints =
            {
                new Point(35, 90),
                //new Point(35,164),
                //new Point(100,164),
                //new Point(100,169),
                //new Point(35,169),
                new Point(35,242),
                new Point(35+8,242+11),
                new Point(43+170,253),
                new Point(213,628),
                new Point(500,628),
                new Point(500,259),
                new Point(500-18,259),
                new Point(470,247),
                new Point(470,98)
            };
            g.DrawLines(penH, redPoints);
            Pen penB = new Pen(Color.DarkRed, 3);
            Point[] whitePoints =
            {
                new Point(295,90),
                new Point(295,246),
                new Point(295+10,246+12),
                new Point(385,258),
                new Point(385,592),
                new Point(385,640),
                new Point(530,640),
                new Point(530,390),
                new Point(500,390)
            };
            g.DrawLines(penB, whitePoints);
            g.DrawRectangle(penH, 213 + 11, 592 - 12, 50, 142);
            g.DrawRectangle(penB, 385 + 11, 592 - 12, 50, 142);
        }
        #endregion

        private void button7_Click(object sender, EventArgs e)
        {
            Graphics g = CreateGraphics();
            //g.Clear(Color.White);
            this.Dispose();
        }
    }



    #region MyLibrayPaint
    class MyLibray : Form
    {
        public void PaintXia(int LocationX, int LocationY, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 1.5F, 0.5F, 1.5F };
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 3.0F, 2.0F, 3.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 6);
            #endregion
            g.DrawEllipse(pen, LocationX - 2, LocationY, 4, 4);//小⭕：1
            g.DrawEllipse(pen, LocationX - 2, LocationY + 4 + 12, 4, 4);//小⭕：2
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(LocationX - 25, LocationY));//LXJ
            g.DrawEllipse(pen, LocationX + 8, LocationY + 10, 4, 4);//小⭕：3
            g.DrawLine(pen, LocationX + 2, LocationY + 2, LocationX + 8, LocationY + 10);//实线
            g.DrawLine(pen_dash, LocationX, LocationY + 4, LocationX, LocationY + 4 + 12);//虚线
            g.DrawLine(pen_arr, LocationX + 12, LocationY + 30, LocationX + 12, LocationY + 34);//箭头头尖
            g.DrawLine(pen, LocationX + 12, LocationY + 16, LocationX + 12, LocationY + 23);//12,16,12,23
        }
        public void PaintShang(int LocationX, int LocationY, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 1.5F, 0.5F, 1.5F };
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 3.0F, 2.0F, 3.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 6);
            #endregion

            g.DrawEllipse(pen, LocationX - 2, LocationY, 4, 4);//小⭕：1
            g.DrawEllipse(pen, LocationX - 2, LocationY + 4 + 12, 4, 4);//小⭕：2
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(LocationX - 25, LocationY));//ZXJ
            g.DrawEllipse(pen, LocationX + 8, LocationY + 10, 4, 4);//小⭕：3
            g.DrawLine(pen, LocationX + 2, LocationY + 2, LocationX + 8, LocationY + 10);//实线
            g.DrawLine(pen_dash, LocationX, LocationY + 4, LocationX, LocationY + 4 + 12);//虚线
            g.DrawLine(pen_arr, LocationX + 12, LocationY + 18, LocationX + 12, LocationY + 15);//箭头头尖
            g.DrawLine(pen, LocationX + 12, LocationY + 25, LocationX + 12, LocationY + 33);//12,16,12,23
        }
        public void PaintXiaZuo(int LocationX, int LocationY, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 1.5F, 0.5F, 1.5F };
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 3.0F, 2.0F, 3.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 6);
            #endregion

            g.DrawEllipse(pen, LocationX - 2, LocationY, 4, 4);//小⭕：1
            g.DrawEllipse(pen, LocationX - 2, LocationY + 4 + 12, 4, 4);//小⭕：2
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(LocationX +5, LocationY));//TXJ
            g.DrawEllipse(pen, LocationX - 10, LocationY + 10, 4, 4);//小⭕：3
            g.DrawLine(pen, LocationX - 2, LocationY + 2, LocationX - 6, LocationY + 10);//实线
            g.DrawLine(pen_dash, LocationX, LocationY + 4, LocationX, LocationY + 4 + 12);//虚线
            g.DrawLine(pen_arr, LocationX - 10, LocationY + 30, LocationX - 10, LocationY + 34);//箭头头尖
            g.DrawLine(pen, LocationX - 10, LocationY + 16, LocationX - 10, LocationY + 23);//12,16,12,23
        }
        public void PaintXiaZuo2(int LocationX, int LocationY, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 1.5F, 0.5F, 1.5F };
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 3.0F, 2.0F, 3.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 6);
            #endregion
            g.DrawEllipse(pen, LocationX - 2, LocationY, 4, 4);//小⭕：1
            g.DrawEllipse(pen, LocationX - 2, LocationY + 4 + 12, 4, 4);//小⭕：2
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(LocationX - 30, LocationY-5));//LUXJ
            g.DrawEllipse(pen, LocationX - 10, LocationY + 10, 4, 4);//小⭕：3
            g.DrawLine(pen, LocationX - 8, LocationY + 14, LocationX - 2, LocationY + 18);//实线
            g.DrawLine(pen_dash, LocationX, LocationY + 4, LocationX, LocationY + 4 + 12);//虚线
            g.DrawLine(pen_arr, LocationX - 10, LocationY + 30, LocationX - 10, LocationY + 34);//箭头头尖
            g.DrawLine(pen, LocationX - 10, LocationY + 16, LocationX - 10, LocationY + 23);//12,16,12,23
        }
        public void PaintXiaYou(int LocationX, int LocationY, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 1.5F, 0.5F, 1.5F };
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 3.0F, 2.0F, 3.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 6);
            #endregion

            g.DrawEllipse(pen, LocationX - 2, LocationY, 4, 4);//小⭕：1
            g.DrawEllipse(pen, LocationX - 2, LocationY + 4 + 12, 4, 4);//小⭕：2
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(LocationX - 29, LocationY));//LUXJ
            g.DrawEllipse(pen, LocationX + 8, LocationY + 10, 4, 4);//小⭕：3
            g.DrawLine(pen_dash, LocationX + 2, LocationY + 2, LocationX + 8, LocationY + 10);//虚线
            g.DrawLine(pen, LocationX, LocationY + 4, LocationX, LocationY + 4 + 12);//实线
            g.DrawLine(pen_arr, LocationX + 12, LocationY + 30, LocationX + 12, LocationY + 34);//箭头头尖
            g.DrawLine(pen, LocationX + 12, LocationY + 16, LocationX + 12, LocationY + 23);//12,16,12,23
        }
        public void Cir(int x, int y, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            #endregion
            g.DrawEllipse(pen, x - 2, y, 4, 4);
            g.DrawLine(pen, x - 4, y + 6, x + 4, y - 2);
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(x + 4, y - 6));//4,-6,05-8
        }
        public void Rec(int x, int y, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            #endregion
            g.DrawRectangle(pen,x-3,y,6,12);
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(x-33,y-30));
        }
        public void XuHao(int x,int y,string s,PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            #endregion
            g.DrawEllipse(pen, x, y - 6, 12, 12);
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(x, y-6));
        }
    }
    #endregion
    #region 信号灯
    class Sig
    {
        public void PaintAll(int x, int y, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 1.5F, 0.5F, 1.5F };
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 3.0F, 2.0F, 3.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 6);
            #endregion
            //双圆
            g.DrawEllipse(pen, x - 8, y, 16, 16);
            g.DrawEllipse(pen, x - 8 + 11, y, 16, 16);
            //多点
            Point[] All1 =
            {
                new Point(x+11,y),
                new Point(x+11,y-12),
                new Point(x+11+50,y-12),
                new Point(x+11+50,y-12+142),
                new Point(x+50-8,y-12+142),//圈+其他
            };
            Point[] All2 =
            {
                new Point(x+11,y+16),
                new Point(x+11,y+16+60),//圈+~~
                new Point(x+11,y+16+48),
                new Point(x+11+23,y+16+48),
                new Point(x+11+23,y+16+48+11)//继电器极点
            };
            g.DrawLines(pen, All1);
            g.DrawLines(pen, All2);
            g.DrawEllipse(pen, x + 11 - 8, y + 16 + 60, 16, 16);
            g.DrawBezier(pen, x + 11 - 6, y + 16 + 60 + 8, x + 11 - 4, y + 16 + 60 + 4, x + 11 + 4, y + 16 + 60 + 12, x + 11 + 6, y + 16 + 60 + 8);
            g.DrawLine(pen, x + 11, y + 16 + 60 + 16, x + 11, y + 16 + 60 + 16 + 42);
            g.DrawLine(pen, x + 11, y + 134, x + 11 + 16, y + 134);
            g.DrawEllipse(pen, x + 25, y + 130 - 8, 16, 16);//⚪和其他  
            Point[] All3 =
            {
                new Point(x+34,y+122),
                new Point(x+34,y+126),
                new Point(x+37,y+126),
                new Point(x+37,y+128),
                new Point(x+40,y+130)
            };
            g.DrawLines(pen, All3);
            Point[] All4 =
            {
                new Point(x+25,y+134),
                new Point(x+29,y+134),
                new Point(x+32,y+135),
                new Point(x+36,y+133),
                new Point(x+40,y+130)

            };
            g.DrawLines(pen, All4);
            #region 信号灯继电器
            g.DrawEllipse(pen, x + 34 - 2, y + 75, 4, 4);
            g.DrawEllipse(pen, x + 34 - 2, y + 75 + 15 + 4, 4, 4);
            g.DrawLine(pen, x + 34, y + 75 + 4, x + 34, y + 75 + 4 + 15);//实线
            g.DrawEllipse(pen, x + 34 + 8, y + 75 + 4 + 6, 4, 4); //右⚪
            g.DrawLine(pen_arr, x + 44, y + 85 - 10, x + 44, y + 85 - 4);//箭头头尖
            g.DrawLine(pen, x + 44, y + 75, x + 44, y + 60);
            g.DrawLine(pen_dash, x + 34 + 2, y + 94 + 2, x + 34 + 8, y + 75 + 4 + 6);//虚线
            g.DrawLine(pen, x + 34, y + 98, x + 34, y + 130 - 8);
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(x + 26, y + 140));
            #endregion
        }
        public void PaintAll2(int x, int y, string s, PaintEventArgs e)
        {
            #region 画笔设置
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2);
            Pen pen_dash = new Pen(Color.Black, 2);
            pen_dash.DashPattern = new float[] { 1.5F, 0.5F, 1.5F };
            Pen pen_arr = new Pen(Color.Black, 2);
            pen_arr.DashPattern = new float[] { 3.0F, 2.0F, 3.0F };
            pen_arr.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 6);
            #endregion
            //双圆
            g.DrawEllipse(pen, x - 8, y, 16, 16);
            g.DrawEllipse(pen, x - 8 + 11, y, 16, 16);
            //多点
            Point[] All1 =
            {
                new Point(x+11,y),
                new Point(x+11,y-12),
                new Point(x+11+50,y-12),
                new Point(x+11+50,y-12+142),
                new Point(x+50-8,y-12+142),//圈+其他
            };
            g.DrawLines(pen, All1);
            Point[] All2 =
            {
                new Point(x+11,y+16),
                new Point(x+11,y+16+60),//圈+~~
                new Point(x+11,y+16+48),
                new Point(x+11+23,y+16+48),
                new Point(x+11+23,y+16+48+11)//继电器极点
            };
            g.DrawLines(pen, All2);
            Point[] All3 =
{
                new Point(x+34,y+122),
                new Point(x+34,y+126),
                new Point(x+37,y+126),
                new Point(x+37,y+128),
                new Point(x+40,y+130)
            };
            g.DrawLines(pen, All3);
            Point[] All4 =
            {
                new Point(x+25,y+134),
                new Point(x+29,y+134),
                new Point(x+32,y+135),
                new Point(x+36,y+133),
                new Point(x+40,y+130)

            };
            g.DrawLines(pen, All4);
            g.DrawEllipse(pen, x + 11 - 8, y + 16 + 60, 16, 16);
            g.DrawBezier(pen, x + 11 - 6, y + 16 + 60 + 8, x + 11 - 4, y + 16 + 60 + 4, x + 11 + 4, y + 16 + 60 + 12, x + 11 + 6, y + 16 + 60 + 8);
            g.DrawLine(pen, x + 11, y + 16 + 60 + 16, x + 11, y + 16 + 60 + 16 + 42);
            g.DrawLine(pen, x + 11, y + 134, x + 11 + 16, y + 134);
            g.DrawEllipse(pen, x + 25, y + 130 - 8, 16, 16);//⚪和其他  

            #region 信号灯继电器
            g.DrawEllipse(pen, x + 34 - 2, y + 75, 4, 4);
            g.DrawEllipse(pen, x + 34 - 2, y + 75 + 15 + 4, 4, 4);
            g.DrawLine(pen_dash, x + 34, y + 75 + 4, x + 34, y + 75 + 4 + 15);//虚线
            g.DrawEllipse(pen, x + 34 + 8, y + 75 + 4 + 6, 4, 4); //右⚪
            g.DrawLine(pen_arr, x + 44, y + 66, x + 44, y + 60);//箭头头尖
            g.DrawLine(pen, x + 44, y + 60, x + 44, y + 81);
            g.DrawLine(pen, x + 34 + 2, y + 94 + 2, x + 34 + 8, y + 75 + 4 + 6);//实线
            g.DrawLine(pen, x + 34, y + 98, x + 34, y + 130 - 8);
            g.DrawString(s, new Font("微软雅黑", 8), new SolidBrush(Color.Black), new PointF(x + 26, y + 140));
            #endregion

        }
        //public void PaintXy(int x, int y, PaintEventArgs e)
        //{
        //    e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        //    Graphics g = e.Graphics;//创建画板
        //    Pen pen = new Pen(Color.DarkMagenta, 3);
        //    g.DrawRectangle(pen, x + 11, y - 12, 50, 142);
        //}
        
    }
    #endregion
}
