﻿namespace 电灯电路图.Properties
{
    class Resources
    {
    }
}