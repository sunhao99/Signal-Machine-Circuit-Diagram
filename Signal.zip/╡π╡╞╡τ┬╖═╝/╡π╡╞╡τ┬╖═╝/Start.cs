﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 电灯电路图
{
    public partial class Start : Form
    {
        public Start()
        {
            InitializeComponent();
        }
        //登陆界面--登录按钮
        private void button1_Click(object sender, EventArgs e)
        {

            //获取输入的用户名和密码信息，方便后面验证
            string LoginID = txt_login.Text.ToString();
            string passwd = txt_pwd.Text.ToString();

            //用户名或密码为空的情况，此处界面中要有label标签显示提示信息
            if (LoginID.Equals("") || passwd.Equals(""))
            {
                MessageBox.Show("用户名和密码不能为空！");
            }
            //用户名或密码不为空的情况   
            else
            {
                string connectionString = "server=SIFF;database=People2022;integrated security=SSPI";  //连接数据库，服务器名称SIFF（即主机名），数据库名称Tuyuan,本地连接integrated security=SSPI
                SqlConnection SqlCon = new SqlConnection(connectionString); //数据库连接
                SqlCon.Open(); //打开数据库
                string sql = "Select * from PEOPLE where PEOPLE='" + LoginID + "' and PEOPLEKEY='" + passwd + "'";//查找用户sql语句
                SqlCommand cmd = new SqlCommand(sql, SqlCon);
                cmd.CommandType = CommandType.Text;
                SqlDataReader sdr;
                sdr = cmd.ExecuteReader();
                if (sdr.Read())         //从结果中找到
                {
                    //信息验证成功，跳转到主界面frmLogin(自己所建立的界面，用textBox显示验证信息也可，自己灵活设置)，关闭登录界面；
                    //此三行代码常用于实现winform窗体之间的切换；其前两行是必须的
                    Form1 f1 = new Form1();
                    f1.Show();
                    MessageBox.Show("登陆成功！");
                    this.Hide();
                }
                //输入用户名和密码错误的情况
                else
                {
                    MessageBox.Show("用户名或密码错误!");
                    return;
                }

            }

            //string LoginID = txt_login.Text;
            //string passwd = txt_pwd.Text;
            ////非空验证
            //if (LoginID == "" || passwd == "")
            //{
            //    MessageBox.Show("用户名和密码不能为空！");
            //    return;
            //}
            ////用户名和密码验证
            //if (LoginID == "sa" && passwd == "123")
            //{
            //    //显示主界面
            //    Form1 f1 = new Form1();
            //    f1.Show();

            //    //关闭登录窗体
            //    this.Hide();
            //}
            //else
            //{
            //    //登录失败
            //    MessageBox.Show("用户名或密码错误!");
            //}
        }

            private void Start_Load(object sender, EventArgs e)
            {

            }
            //取消按钮

            private void button2_Click(object sender, EventArgs e)
            {
                this.Close();
            }

            private void Start_FormClosed(object sender, FormClosedEventArgs e)
            {
                //退出应用程序
                Application.Exit();
            }

    }
}
