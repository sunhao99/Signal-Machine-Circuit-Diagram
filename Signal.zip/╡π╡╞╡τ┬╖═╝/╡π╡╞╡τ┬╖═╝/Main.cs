﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using 进站信号机电灯电路;
namespace 电灯电路图
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Jinzhan_Click(object sender, EventArgs e)
        {
            //调用进站信号机电灯电路图
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("欢迎使用信号电灯电路图软件！");
        }

        private void Diaoche_Click(object sender, EventArgs e)
        {
            Form2 form2= new Form2();
            form2.ShowDialog();
        }

        private void Chuzhan_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            //应用程序关闭
            Application.Exit();
        }
    }
}
