﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 电灯电路图
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;//创建画板
            Pen pen = new Pen(Color.Black, 2); //定义了一个黑色,宽度为2的画笔
            g.DrawLine(pen, 30, 0, 1200, 0);//画直线
            g.DrawLine(pen, 30, 660, 1200, 660);//画直线
            g.DrawLine(pen, 1200,660, 1200, 0);//画直线
            g.DrawLine(pen, 30,0, 30, 660);//画直线
            g.DrawLine(pen, 50, 515, 1200, 515);//画直线
            g.DrawLine(pen, 900, 0, 900, 750);//画直线

            g.DrawLine(pen, 150, 20, 150, 130);//画直线
            g.DrawLine(pen, 145, 30, 155, 30);//画直线,dz
            g.DrawLine(pen, 155, 30, 155, 50);//画直线,dz
            g.DrawLine(pen, 155, 50, 145, 50);//画直线,dz
            g.DrawLine(pen, 145, 50, 145, 30);//画直线,dz
            g.DrawLine(pen, 150, 100, 500, 100);//画直线
            g.DrawLine(pen, 523, 100, 800, 100);//画直线

            g.DrawLine(pen, 150, 130, 200, 130);//画直线
            g.DrawLine(pen, 223, 130, 300, 130);//画直线

            g.DrawLine(pen, 300, 130, 300, 70);//画直线
            g.DrawLine(pen, 300, 70, 800, 70);//画直线
            g.DrawLine(pen, 795, 30, 805, 30);//画直线,dz
            g.DrawLine(pen, 805, 30, 805, 50);//画直线,dz
            g.DrawLine(pen, 805, 50, 795, 50);//画直线,dz
            g.DrawLine(pen, 795, 50, 795, 30);//画直线,dz111111
            g.DrawEllipse(pen, 200, 120, 25, 25); //画椭圆s1
            g.DrawLine(pen, 150, 150, 200, 150);//画直线
            g.DrawLine(pen, 223, 150, 800, 150);//画直线
            g.DrawEllipse(pen, 200, 140, 25, 25); //画椭圆s1
            g.DrawEllipse(pen, 500, 90, 25, 25); //画椭圆s2
            g.DrawEllipse(pen, 500, 110, 25, 25); //画椭圆s2
            g.DrawLine(pen, 370, 120, 500, 120);//画直线
            g.DrawLine(pen, 523, 120, 800, 120);//画直线
            g.DrawLine(pen, 150, 150, 150,220);//画直线
            g.DrawLine(pen, 370, 120,370, 290);//画直线

            g.DrawEllipse(pen, 130, 160, 40, 40); //画椭圆DJ
            g.DrawLine(pen, 140, 175, 160, 175);//画直线
            g.DrawLine(pen, 140, 175,150, 187);//画直线
            g.DrawLine(pen, 160, 175, 150, 187);//画直线
            g.DrawLine(pen, 140, 187, 160, 187);//画直线

            g.DrawEllipse(pen, 350, 160, 40, 40); //画椭圆2DJ
            g.DrawLine(pen, 360, 175, 380, 175);//画直线
            g.DrawLine(pen, 360, 175, 370, 187);//画直线
            g.DrawLine(pen, 380, 175, 370, 187);//画直线
            g.DrawLine(pen, 360, 187, 380, 187);//画直线

            g.DrawLine(pen, 690, 195, 770, 195);//画直线,2LXF
            g.DrawLine(pen, 690, 195, 690, 215);//画直线
            g.DrawLine(pen, 730,195, 730, 215);//画直线

            g.DrawEllipse(pen, 147, 220, 6, 6); //画椭圆LXJ上
            g.DrawEllipse(pen, 147, 250, 6, 6); //画椭圆LXJ下
            g.DrawEllipse(pen, 166, 235 , 6, 6); //画椭圆LXJ中
            g.DrawLine(pen, 153, 223, 166, 235);//画直线
            g.DrawLine(pen, 172, 238, 250, 238);//画直线

            g.DrawEllipse(pen, 250, 235, 6, 6); //画椭圆DXJ左
            g.DrawEllipse(pen, 280, 235, 6, 6); //画椭圆DXJ右
            g.DrawEllipse(pen,265, 254, 6, 6); //画椭圆DXJ下
            g.DrawLine(pen, 253, 241, 268, 254);//画直线
            g.DrawLine(pen, 268, 260, 268, 530);//画直线,qqqqqqqqqqqqqq
            g.DrawLine(pen, 286, 238, 510, 238);//画直线
            g.DrawLine(pen, 510,238, 510, 530);//画直线


            g.DrawLine(pen, 150, 256, 150, 300);//画直线
            g.DrawEllipse(pen, 147, 300, 6, 6); //画椭圆ZXJ上
            g.DrawEllipse(pen, 147, 330, 6, 6); //画椭圆ZXJ下
            g.DrawEllipse(pen, 128, 315, 6, 6); //画椭圆ZXJ中
            g.DrawLine(pen, 147, 303, 134, 315);//画直线
            g.DrawLine(pen, 128, 318, 108, 318);//画直线
            g.DrawLine(pen, 108, 318, 108, 350);//画直线

            g.DrawEllipse(pen, 105, 350, 6, 6); //画椭圆3DJ上
            g.DrawEllipse(pen, 105, 380, 6, 6); //画椭圆3DJ下
            g.DrawEllipse(pen, 124, 365, 6, 6); //画椭圆3DJ中
            g.DrawLine(pen, 111, 353, 127, 365);//画直线
            g.DrawLine(pen, 108,386, 108, 438);//画直线
            g.DrawLine(pen, 108, 438, 150, 438);//画直线




            g.DrawLine(pen, 150, 336, 150, 350);//画直线
            g.DrawEllipse(pen, 147, 350, 6, 6); //画椭圆2LQJ上
            g.DrawEllipse(pen, 147, 380, 6, 6); //画椭圆2LQJ下
            g.DrawEllipse(pen, 166, 365, 6, 6); //画椭圆2LQJ中
            g.DrawLine(pen, 153, 353, 166, 365);//画直线

            g.DrawLine(pen, 150, 386, 150, 400);//画直线
            g.DrawEllipse(pen, 147, 400, 6, 6); //画椭圆3LQJ上
            g.DrawEllipse(pen, 147, 430, 6, 6); //画椭圆3LQJ下
            g.DrawEllipse(pen, 166, 415, 6, 6); //画椭圆3LQJ中
            g.DrawLine(pen, 153, 403, 166, 415);//画直线
            g.DrawLine(pen, 150, 436, 150, 530);//画直线,QQQQQQQQQQQQQ

            g.DrawLine(pen, 172, 421, 235, 421);//画直线
            g.DrawLine(pen, 235, 451, 235, 421);//画直线
            g.DrawEllipse(pen, 232,451, 6, 6); //画椭圆2DJ上
            g.DrawEllipse(pen, 232, 481, 6, 6); //画椭圆2DJ下
            g.DrawEllipse(pen, 213, 466, 6, 6); //画椭圆2DJ中
            g.DrawLine(pen, 232, 454, 216, 466);//画直线
            g.DrawLine(pen, 235, 487, 235, 494);//画直线
            g.DrawLine(pen, 235, 494, 150, 494);//画直线
            g.DrawLine(pen, 460, 295, 460,275);//画直线
            g.DrawLine(pen, 420, 295, 420, 275);//画直线
            g.DrawLine(pen, 420, 295, 500, 295);//画直线

            g.DrawEllipse(pen,367, 290, 6, 6); //画椭圆LXJF上
            g.DrawEllipse(pen,367, 320, 6, 6); //画椭圆LXJF下
            g.DrawEllipse(pen, 386, 305, 6, 6); //画椭圆LXJF中
            g.DrawLine(pen, 373, 293, 389, 305);//画直线

            g.DrawLine(pen, 370, 326, 370, 340);//画直线
            g.DrawEllipse(pen, 367, 340, 6, 6); //画椭圆ZXJ上
            g.DrawEllipse(pen, 367, 370, 6, 6); //画椭圆ZXJ下
            g.DrawEllipse(pen, 386, 355, 6, 6); //画椭圆ZXJ中
            g.DrawLine(pen, 373, 342, 389, 355);//画直线

            g.DrawLine(pen, 370, 376, 370, 390);//画直线
            g.DrawEllipse(pen, 367, 390, 6, 6); //画椭圆3LQJF上
            g.DrawEllipse(pen, 367, 420, 6, 6); //画椭圆3LQJF下
            g.DrawEllipse(pen, 348, 405, 6, 6); //画椭圆3LQJF中
            g.DrawLine(pen, 367, 393, 354, 405);//画直线

            g.DrawLine(pen, 370, 426, 370, 440);//画直线
            g.DrawEllipse(pen, 367, 440, 6, 6); //画椭圆2LQJF上
            g.DrawEllipse(pen, 367, 470, 6, 6); //画椭圆2LQJF下
            g.DrawEllipse(pen, 348, 455, 6, 6); //画椭圆2LQJF中
            g.DrawLine(pen, 370, 446, 370, 470);//画直线
            g.DrawLine(pen, 348, 458, 318, 458);//画直线
            g.DrawLine(pen, 172, 368, 318, 368);//画直线
            g.DrawLine(pen, 318, 368, 318, 458);//画直线
            g.DrawLine(pen, 90, 445, 90, 465);//画直线
            g.DrawLine(pen, 370, 476, 370, 530);//画直线，qqqqqqq

            g.DrawEllipse(pen, 137, 530, 25, 25); //画椭圆s1
            g.DrawEllipse(pen, 157, 530, 25, 25); //画椭圆s1
            g.DrawLine(pen, 152, 555, 152, 580);//画直线
            g.DrawLine(pen,152, 580, 800, 580);//画直线,800DD
            g.DrawLine(pen, 170, 530, 170, 520);//画直线
            g.DrawLine(pen, 170, 520,220, 520);//画直线
            g.DrawLine(pen, 220, 520, 220, 640);//画直线
            g.DrawLine(pen, 170, 555, 170, 600);//画直线
            g.DrawEllipse(pen, 157, 600, 25, 25); //画椭圆s1
            g.DrawLine(pen, 170, 625, 170, 640);//画直线
            g.DrawLine(pen, 170, 640, 180, 640);//画直线
            g.DrawEllipse(pen, 180, 627, 25, 25); //画椭圆s1
            g.DrawLine(pen, 205, 640, 220, 640);//画直线
            g.DrawLine(pen, 170,590, 192, 590);//画直线
            g.DrawLine(pen, 192, 590, 192, 595);//画直线
            g.DrawEllipse(pen, 189, 595, 6, 6); //画椭圆上
            g.DrawEllipse(pen, 189, 620, 6, 6); //画椭圆下
            g.DrawEllipse(pen, 208, 610, 6, 6); //画椭圆中
            g.DrawLine(pen, 192, 601, 192, 620);//画直线

            g.DrawEllipse(pen, 255, 530, 25, 25); //画椭圆s2
            g.DrawEllipse(pen, 276, 530, 25, 25); //画椭圆s2
            g.DrawLine(pen, 270, 555, 270, 585);//画直线
            g.DrawLine(pen, 270, 585, 840, 585);//画直线,800DD
            g.DrawLine(pen, 288, 530, 288, 520);//画直线
            g.DrawLine(pen, 288, 520, 338, 520);//画直线
            g.DrawLine(pen, 338, 520, 338, 640);//画直线
            g.DrawLine(pen, 288, 555, 288, 600);//画直线
            g.DrawEllipse(pen, 275, 600, 25, 25); //画椭圆s2
            g.DrawLine(pen, 288, 625, 288, 640);//画直线
            g.DrawLine(pen, 288, 640, 298, 640);//画直线
            g.DrawEllipse(pen, 298, 627, 25, 25); //画椭圆s2
            g.DrawLine(pen, 323, 640, 338, 640);//画直线
            g.DrawLine(pen, 288, 590, 310, 590);//画直线
            g.DrawLine(pen, 310, 590, 310, 595);//画直线
            g.DrawEllipse(pen, 307, 595, 6, 6); //画椭圆上
            g.DrawEllipse(pen, 307, 620, 6, 6); //画椭圆下
            g.DrawEllipse(pen,326, 610, 6, 6); //画椭圆中
            g.DrawLine(pen, 310, 601, 310, 620);//画直线

            g.DrawEllipse(pen, 357, 530, 25, 25); //画椭圆s3
            g.DrawEllipse(pen, 377, 530, 25, 25); //画椭圆s3
            g.DrawLine(pen, 372, 555, 372, 580);//画直线
            g.DrawLine(pen, 390, 530, 390, 520);//画直线
            g.DrawLine(pen, 390, 520, 440, 520);//画直线
            g.DrawLine(pen, 440, 520, 440, 640);//画直线
            g.DrawLine(pen, 390, 555, 390, 600);//画直线
            g.DrawEllipse(pen, 377, 600, 25, 25); //画椭圆s3
            g.DrawLine(pen, 390, 625, 390, 640);//画直线
            g.DrawLine(pen, 390, 640, 400, 640);//画直线
            g.DrawEllipse(pen, 400, 627, 25, 25); //画椭圆s3
            g.DrawLine(pen, 425, 640,440, 640);//画直线
            g.DrawLine(pen, 390, 590,412, 590);//画直线
            g.DrawLine(pen, 412, 590, 412, 595);//画直线
            g.DrawEllipse(pen, 409, 595, 6, 6); //画椭圆上
            g.DrawEllipse(pen, 409, 620, 6, 6); //画椭圆下
            g.DrawEllipse(pen, 428, 610, 6, 6); //画椭圆中
            g.DrawLine(pen, 412, 601, 412, 620);//画直线

            g.DrawEllipse(pen, 497, 530, 25, 25); //画椭圆s4
            g.DrawEllipse(pen, 517, 530, 25, 25); //画椭圆s4
            g.DrawLine(pen, 512, 555, 512, 585);//画直线
            g.DrawLine(pen, 530, 530, 530, 520);//画直线
            g.DrawLine(pen, 530, 520, 580, 520);//画直线
            g.DrawLine(pen, 580, 520, 580, 640);//画直线
            g.DrawLine(pen, 530, 555, 530, 600);//画直线
            g.DrawEllipse(pen, 517, 600, 25, 25); //画椭圆s4
            g.DrawLine(pen, 530, 625, 530, 640);//画直线
            g.DrawLine(pen, 530, 640, 540, 640);//画直线
            g.DrawEllipse(pen, 540, 627, 25, 25); //画椭圆s4
            g.DrawLine(pen, 565, 640, 580, 640);//画直线
            g.DrawLine(pen, 530, 590, 552, 590);//画直线
            g.DrawLine(pen, 552, 590, 552, 595);//画直线
            g.DrawEllipse(pen, 549, 595, 6, 6); //画椭圆上
            g.DrawEllipse(pen, 549, 620, 6, 6); //画椭圆下
            g.DrawEllipse(pen, 568, 610, 6, 6); //画椭圆中
            g.DrawLine(pen, 552, 601, 552, 620);//画直线

            g.DrawLine(pen, 800, 120, 800, 250);//画直线
            g.DrawEllipse(pen, 797, 250, 6, 6); //画椭圆上1XJ
            g.DrawEllipse(pen, 797, 280, 6, 6); //画椭圆下1XJ
            g.DrawEllipse(pen, 816, 265, 6, 6); //画椭圆中1XJ
            g.DrawLine(pen, 800, 580, 800, 286);//画直线
            g.DrawLine(pen, 803, 253, 819, 265);//画直线
            g.DrawLine(pen, 820, 268, 840, 268);//画直线
            g.DrawLine(pen, 840, 268, 840, 585);//画直线
            g.DrawLine(pen, 800, 100, 800, 15);//画直线

            g.DrawLine(pen, 950, 20, 950, 130);//画直线
            g.DrawLine(pen, 945, 30, 955, 30);//画直线,dz
            g.DrawLine(pen, 955, 30, 955, 50);//画直线,dz
            g.DrawLine(pen, 955, 50, 945, 50);//画直线,dz
            g.DrawLine(pen, 945, 50, 945, 30);//画直线,dz
            g.DrawLine(pen, 950, 130, 1000, 130);//画直线,dz
            g.DrawEllipse(pen, 1000, 118, 25, 25); //画椭圆s4
            g.DrawEllipse(pen, 1000, 138, 25, 25); //画椭圆s4
            g.DrawLine(pen, 1025, 130, 1120, 130);//画直线


            g.DrawLine(pen, 950, 150, 950, 300);//画直线AAAAAAA
            g.DrawLine(pen, 950, 150, 1000, 150);//画直线
            g.DrawLine(pen, 1025, 150, 1120, 150);//画直线
            g.DrawLine(pen, 1120, 150, 1120, 300);//画直线,AAAAA
            g.DrawEllipse(pen, 930, 170, 40, 40); //画椭圆3DJ
            g.DrawLine(pen, 940, 185, 960, 185);//画直线
            g.DrawLine(pen, 940, 185, 950, 197);//画直线
            g.DrawLine(pen, 960, 185, 950, 197);//画直线
            g.DrawLine(pen, 940, 197, 960, 197);//画直线
            




            g.DrawLine(pen, 1120, 130, 1120, 20);//画直线
            g.DrawLine(pen, 1115, 30, 1125, 30);//画直线,dz
            g.DrawLine(pen, 1125, 30, 1125, 50);//画直线,dz
            g.DrawLine(pen, 1115, 50, 1115, 30);//画直线,dz
            g.DrawLine(pen, 1115, 50, 1125, 50);//画直线,dz

            g.DrawEllipse(pen,947, 300, 6, 6); //画椭圆上LXJF
            g.DrawEllipse(pen,947, 330, 6, 6); //画椭圆下LXJF
            g.DrawEllipse(pen,966, 315, 6, 6); //画椭圆中LXJF
            g.DrawLine(pen, 953, 306, 969, 315);//画直线,dz

            g.DrawLine(pen, 950, 336, 950, 350);//画直线,dz
            g.DrawEllipse(pen, 947, 350, 6, 6); //画椭圆上ZXJ
            g.DrawEllipse(pen, 947, 380, 6, 6); //画椭圆下ZXJ
            g.DrawEllipse(pen, 966, 365, 6, 6); //画椭圆中ZXJ
            g.DrawLine(pen, 953, 356, 969, 365);//画直线,dz
            g.DrawLine(pen, 950, 386, 950, 530);//画直线,dz

            g.DrawEllipse(pen, 1117, 300, 6, 6); //画椭圆上ZXJ
            g.DrawEllipse(pen, 1117, 330, 6, 6); //画椭圆下ZXJ
            g.DrawEllipse(pen, 1136, 315, 6, 6); //画椭圆中ZXJ
            g.DrawLine(pen, 1123, 303, 1139, 318);//画直线,dz
            g.DrawLine(pen, 1120, 336, 1120, 585);//画直线,dz

            g.DrawEllipse(pen, 937, 530, 25, 25); //画椭圆s5
            g.DrawEllipse(pen, 958, 530, 25, 25); //画椭圆s5
            g.DrawLine(pen, 952, 555, 952, 585);//画直线
            g.DrawLine(pen, 952, 585, 1120, 585);//画直线,800DD
            g.DrawLine(pen,970, 530, 970, 520);//画直线
            g.DrawLine(pen, 970, 520, 1020, 520);//画直线
            g.DrawLine(pen, 1020, 520, 1020, 640);//画直线
            g.DrawLine(pen, 970, 555, 970, 600);//画直线
            g.DrawEllipse(pen, 957, 600, 25, 25); //画椭圆s5
            g.DrawLine(pen, 970, 625, 970, 640);//画直线
            g.DrawLine(pen, 970, 640, 980, 640);//画直线
            g.DrawEllipse(pen, 980, 627, 25, 25); //画椭圆s5
            g.DrawLine(pen, 1005, 640, 1020, 640);//画直线
            g.DrawLine(pen, 970, 590, 992, 590);//画直线
            g.DrawLine(pen, 992, 590, 992, 595);//画直线
            g.DrawEllipse(pen, 989, 595, 6, 6); //画椭圆上
            g.DrawEllipse(pen, 989, 620, 6, 6); //画椭圆下
            g.DrawEllipse(pen, 1008, 610, 6, 6); //画椭圆中
            g.DrawLine(pen, 992, 601, 992, 620);//画直线

            g.DrawLine(pen, 145, 10, 150, 20);//画直线
            g.DrawLine(pen, 155, 10,150, 20);//画直线
            g.DrawLine(pen, 945, 10, 950, 20);//画直线
            g.DrawLine(pen, 955, 10,950, 20);//画直线

            g.DrawRectangle(pen, 1000, 0, 80, 20);//画矩形
            g.DrawLine(pen, 1040, 0, 1040, 20);//画直线
          
            g.DrawRectangle(pen, 1000, 230, 80, 20);//画矩形
            g.DrawLine(pen, 1040, 230, 1040, 250);//画直线

            g.DrawRectangle(pen, 1000, 260, 80, 20);//画矩形
            g.DrawLine(pen, 1040, 260, 1040, 280);//画直线

            g.DrawString("BXO", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1000, 0));//绘制文字
            g.DrawString("DJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1000, 230));//绘制文字
            g.DrawString("DJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(50,445));//绘制文字
            g.DrawString("2LXF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1000, 260));//绘制文字
            g.DrawString("52-6", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1040, 0));//绘制文字
            g.DrawString("52-7", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1040, 230));//绘制文字
            g.DrawString("52-7", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(90, 445));//绘制文字
            g.DrawString("DJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(170, 170));//绘制文字
            g.DrawString("2DJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(390, 170));//绘制文字
            g.DrawString("3DJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(980, 185));//绘制文字
            g.DrawString("LXJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(980, 300));//绘制文字
            g.DrawString("2LXJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(420, 275));//绘制文字
            g.DrawString("2LXJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(690, 195));//绘制文字
            g.DrawString("ZXJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(980, 360));//绘制文字
            g.DrawString("LXJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1080, 300));//绘制文字
            g.DrawString("XJZ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(945, 0));//绘制文字
            g.DrawString("XJZ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(145, 0));//绘制文字
            g.DrawString("XJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(795, 0));//绘制文字
            g.DrawString("XJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1115, 0));//绘制文字
            g.DrawString("BXG1", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(200, 80));//绘制文字
            g.DrawString("BXG2", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(500, 54));//绘制文字
            g.DrawString("BXG3", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1010, 90));//绘制文字
            g.DrawString("DLQ1", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(105, 30));//绘制文字
            g.DrawString("DLQ2", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(755, 30));//绘制文字
            g.DrawString("DLQ3", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(970, 30));//绘制文字
            g.DrawString("DLQ4", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1075, 30));//绘制文字
            g.DrawString("B-B", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(1025, 640));//绘制文字
            g.DrawString("B", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(585, 640));//绘制文字
            g.DrawString("U", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(445, 640));//绘制文字
            g.DrawString("H", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(343, 640));//绘制文字
            g.DrawString("L", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(225, 640));//绘制文字
            g.DrawString("LXJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(120, 235));//绘制文字
            g.DrawString("DXJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(260, 220));//绘制文字
            g.DrawString("ZXJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(150, 305));//绘制文字
            g.DrawString("2LQJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(165, 370));//绘制文字
            g.DrawString("3LQJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(165, 420));//绘制文字
            g.DrawString("3DJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(65, 370));//绘制文字
            g.DrawString("2DJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(175, 470));//绘制文字
            g.DrawString("LXJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(390, 295));//绘制文字
            g.DrawString("ZXJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(390, 345));//绘制文字
            g.DrawString("3LQJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(372, 395));//绘制文字
            g.DrawString("2LQJF", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(372, 445));//绘制文字
            g.DrawString("LXJ", new Font("宋体", 10), new SolidBrush(Color.Black), new PointF(775, 270));//绘制文字




            pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;//虚线
            g.DrawLine(pen, 340, 0, 340, 215);//画直线
            g.DrawLine(pen, 340, 215, 770, 215);//画直线
            g.DrawLine(pen, 770, 215, 770, 0);//画直线
            g.DrawLine(pen, 150, 226, 150, 250);//画直线
            g.DrawLine(pen, 256,238 ,280 ,238);//画直线
            g.DrawLine(pen, 150, 306, 150, 330);//画直线
            g.DrawLine(pen, 50, 275, 500,275);//画直线
            g.DrawLine(pen, 500, 275, 500, 500);//画直线
            g.DrawLine(pen, 50, 275, 50, 500);//画直线
            g.DrawLine(pen, 50, 500, 500, 500);//画直线
            g.DrawLine(pen, 150, 356, 150, 380);//画直线
            g.DrawLine(pen, 150, 406, 150, 430);//画直线
            g.DrawLine(pen, 235, 457, 235, 481);//画直线
            g.DrawLine(pen,108, 380, 108, 356);//画直线
            g.DrawLine(pen, 50, 342, 350, 342);//画直线
            g.DrawLine(pen, 350, 342, 350, 385);//画直线
            g.DrawLine(pen, 350, 385, 410, 385);//画直线
            g.DrawLine(pen, 370, 296, 370, 320);//画直线
            g.DrawLine(pen, 370, 346, 370, 370);//画直线
            g.DrawLine(pen, 50, 445, 248, 445);//画直线
            g.DrawLine(pen, 248, 445, 248, 485);//画直线
            g.DrawLine(pen, 248, 485, 410, 485);//画直线
            g.DrawLine(pen, 410, 485, 410, 385);//画直线
            g.DrawLine(pen, 370, 396, 370, 420);//画直线
            g.DrawLine(pen, 351, 461, 367, 473);//画直线
            g.DrawLine(pen, 50, 465, 134, 465);//画直线
            g.DrawLine(pen, 134, 465,134, 342);//画直线
            g.DrawLine(pen, 198, 623, 211, 613);//画直线
            g.DrawLine(pen, 316, 623, 329, 613);//画直线
            g.DrawLine(pen, 418, 623, 431, 613);//画直线
            g.DrawLine(pen, 558, 623, 571, 613);//画直线
            g.DrawLine(pen, 800, 256, 800, 280);//画直线
            g.DrawLine(pen, 950, 306, 950, 330);//画直线,dz
            g.DrawLine(pen, 950, 356, 950, 380);//画直线,dz
            g.DrawLine(pen, 1120, 306, 1120, 330);//画直线,dz
            g.DrawLine(pen, 992, 623, 1011, 616);//画直线
            g.DrawLine(pen, 900, 165, 1200, 165);//画直线
            g.DrawLine(pen, 900, 250, 1200, 250);//画直线







            pen.CustomEndCap = new System.Drawing.Drawing2D.AdjustableArrowCap(3, 5);
            g.DrawLine(pen, 800, 100, 800, 15);//画直线
            g.DrawLine(pen,166, 255, 166, 275);//画直线
            g.DrawLine(pen, 286, 255, 286, 275);//画直线
            g.DrawLine(pen, 140, 320, 140, 340);//画直线
            g.DrawLine(pen, 166, 395, 166, 375);//画直线
            g.DrawLine(pen, 166, 445, 166, 425);//画直线
            g.DrawLine(pen, 225, 461, 225, 481);//画直线
            g.DrawLine(pen,380, 305, 380, 325);//画直线
            g.DrawLine(pen, 380, 355, 380, 375);//画直线
            g.DrawLine(pen, 365, 425, 365, 405);//画直线
            g.DrawLine(pen, 362, 470, 362, 450);//画直线
            g.DrawLine(pen, 114, 365, 114, 385);//画直线
            g.DrawLine(pen, 200, 595, 200, 615);//画直线
            g.DrawLine(pen, 318, 615, 318, 595);//画直线
            g.DrawLine(pen, 420, 595, 420, 615);//画直线
            g.DrawLine(pen, 560, 595, 560, 615);//画直线
            g.DrawLine(pen, 808,265, 808, 285);//画直线
            g.DrawLine(pen, 1120, 130, 1120, 10);//画直线
            g.DrawLine(pen, 960, 325, 960, 345);//画直线,dz
            g.DrawLine(pen, 960, 375, 960, 395);//画直线,dz
            g.DrawLine(pen, 1130, 315, 1130,335 );//画直线,dz
            g.DrawLine(pen, 1000, 595, 1000, 615);//画直线
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
