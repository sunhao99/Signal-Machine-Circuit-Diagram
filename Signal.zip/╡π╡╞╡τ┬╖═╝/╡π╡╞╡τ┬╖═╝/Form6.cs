﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 电灯电路图
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void userpwz_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }
        private void zc_Click(object sender, EventArgs e)
        {
            string userID = userid.Text.Trim();
            string constr = "server=SIFF;database=People2022;integrated security=SSPI";
            SqlConnection mycon = new SqlConnection(constr);
            mycon.Open();
            SqlCommand checkCmd = mycon.CreateCommand();
            string s = "select account from PEOPLE where account ='" + userID + "'";
            string sl = "insert into username(account,password,name) values ('" + userid.Text + "','" + userpw.Text + "','" + nickname.Text + "')";//输入用户注册的密码和名称
            checkCmd.CommandText = s;
            SqlDataAdapter check = new SqlDataAdapter();
            check.SelectCommand = checkCmd;
            DataSet checkData = new DataSet();
            int n = check.Fill(checkData, "lianxi");
            SqlCommand mycom = new SqlCommand(sl, mycon);
            mycom.ExecuteNonQuery();             //执行语句
            mycon.Close();                       //关闭连接
            mycom = null;
            mycon.Dispose();
            if (userpwz.Text != userpw.Text)//检测两次输入的密码是否相同
            {
                userpwz.Text = "";
                userpw.Text = "";
                MessageBox.Show("两次密码内容不一致");
            }

            else if (userid.Text == "" || nickname.Text == "" || userpwz.Text == "" || this.checkBox1.Checked == false)//检测是否有空缺内容，比如同意用户协议是否没有打勾
            {
                MessageBox.Show("请将信息补充完整");
            }
            else
            {
                MessageBox.Show("注册成功");
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userID = userid.Text.Trim();//获取用户注册的信息
            string constr = "server=SIFF;database=People2022;integrated security=SSPI";//选取数据库
            SqlConnection mycon = new SqlConnection(constr);
            mycon.Open();
            SqlCommand checkCmd = mycon.CreateCommand();
            string s = "select account from PEOPLE where account ='" + userID + "'";//从数据库中查看是否已经存在相同的姓名
            checkCmd.CommandText = s;
            SqlDataAdapter check = new SqlDataAdapter();
            check.SelectCommand = checkCmd;
            DataSet checkData = new DataSet();
            int n = check.Fill(checkData, "lianxi");
            if (n != 0)//表示用户名已经存在
            {
                MessageBox.Show("用户名已存在！");
                userid.Text = "";
                userpw.Text = "";
                nickname.Text = "";
            }
            else
            {
                MessageBox.Show("用户名可以使用。");
            }
        }
    }
}
