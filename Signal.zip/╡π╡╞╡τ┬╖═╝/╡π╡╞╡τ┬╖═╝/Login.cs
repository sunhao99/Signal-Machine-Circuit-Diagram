﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using 电灯电路图;

namespace WindowsFormsApplication2
{
    public partial class Login : Form
    {
        int errortime = 3;//这里设计这个东西是为记录用户的登陆次数，检测其是不是为零。

        public Login()
        {
            InitializeComponent();
            textcheck.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();//点击取消按钮以后退出程序
        }


        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }


        private void Login_Load_1(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            errortime = errortime - 1;//按下去你的可登陆次数就会减一

            string username = txtname.Text;//提取对应的txtbox里面的内容
            string pwd = txtpwd.Text;//提取对应的txtbox里面的内容
            string constr = "server=SIFF;database=People2022;integrated security=SSPI";//"server=SIFF;DataBase=test;uid=sa;pwd=123";//连接数据库以前讲过啦
            SqlConnection mycon = new SqlConnection(constr);
            mycon.Open();
            string sl = "select PEOPLE,PEOPLEKEY from PEOPLE where PEOPLE='" + username + "'and PEOPLEKEY='" + pwd + "'";//这里我们需要将用户名与密码与数据库里存储的用户名与密码做对比
            SqlDataAdapter myda = new SqlDataAdapter(sl, "server=SIFF;database=People2022;integrated security=SSPI");
            DataSet myds = new DataSet();
            int n = myda.Fill(myds, "register");//这里是为了得到一个返回值，如果返回数值步为零，则说明数据库里有这个数值，如果返回值为零则说明数据库里没有对应的用户名与密码，用户登陆失败
            if (n != 0)
            {
                if (textcheck.Text.Trim() == "" || textcheck.Text == null)//判断用户有没有输入正确的验证码
                {
                    MessageBox.Show("请输入验证码");
                }
                else if (textcheck.Text == textcheck.Text)
                {
                    MessageBox.Show("欢迎使用！");
                    this.Hide();//隐藏当前页面
                    Form1 f1 = new Form1();
                    f1.Show();
                    Form5 f5 = new Form5();
                    //f4.GetLoginMsg(this.txtname.Text);  //这个是为了传递字段用的，第一次编程可以不写，但是在第三次教程中会用到，在这里算是提前剧透，这个字段的作用是将txtbox里面的内容从Login传递到Form5      
                }
                else
                {
                    MessageBox.Show("验证码错误！");
                }
            }
            else
            {
                if (errortime < 3 && errortime > 0)//首先判断下用户还有没有机会再次输用户名与密码
                {
                    MessageBox.Show("用户名或者密码有错误。请重新输入！" + errortime.ToString() + "次机会");//告诉电脑前的小子还有几次
                    txtname.Text = "";//为用户清空txtbox里的内容
                    txtpwd.Text = "";//为用户清空txtbox里的内容
                    txtname.Focus();
                }
                else
                {
                    MessageBox.Show("你所输入的用户名和密码已经达到三次。程序将推出");
                    this.Close();//下面让我们把这个东西关了吧
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();//点击用户注册按钮以后，不关闭当前页面，同时打开新页面Form6.
        }

        private void checkCode_Click_1(object sender, EventArgs e)//这个东西是为了生成验证码，不过这次写的简单，毕竟当时没有想着加这个东西，逻辑上还有不合理的东西，所以大家就看看好了
        {
            Random random = new Random();//声明
            int minv = 12345, maxv = 98765;//定义数值的最大值与最小数值
            checkCode.Text = random.Next(minv, maxv).ToString();//生成随机数
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();//点击取消按钮以后退出程序
        }
    }
}