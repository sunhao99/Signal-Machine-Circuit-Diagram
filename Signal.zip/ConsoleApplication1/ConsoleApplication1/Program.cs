﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //窗口显示时间信息：Click--->标题显示时间
            Form form = new Form();
            Controller controller = new Controller(form);
            form.ShowDialog();
        }
    }

    class Controller
    {
        private Form form;

        public Controller(Form form)
        {
            if (form != null)
            {
                this.form = form;
                this.form.Click += this.Formclick;
            }
        }

        private void Formclick(object sender, EventArgs e)
        {
            this.form.Text = DateTime.Now.ToString();
        }

    }
}
